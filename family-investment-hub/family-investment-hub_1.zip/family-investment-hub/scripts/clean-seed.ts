/**
 * Clean production seed — creates ONLY the admin account and the real
 * fund settings. No fictional members, no fake contribution history.
 * Use this instead of seed.ts when preparing the database that goes
 * live for real use.
 *
 * Run with: npm run db:clean
 */
import { newId } from "../lib/ids";
import { hashPassword } from "../lib/auth";
import { run } from "../lib/db";
import { setSetting } from "../lib/repo/settings";

async function main() {
  console.log("Creating clean production database…");

  setSetting("MIN_CONTRIBUTION", "100000");
  setSetting("MAX_CONTRIBUTION", "500000");
  setSetting("MEMBER_DEADLINE_DAY", "10");
  setSetting("UAP_TRANSFER_DEADLINE_DAY", "15");
  setSetting("FUND_NAME", "UAP Umbrella Trust Fund");

  const adminId = newId("user");
  run(`INSERT INTO users (id, email, password_hash, role) VALUES (:id, :email, :hash, 'ADMIN')`, {
    id: adminId,
    email: "admin@family.com",
    hash: await hashPassword("Admin123!"),
  });

  console.log("  ✓ Admin account created: admin@family.com / Admin123!");
  console.log("  ✓ No members, no contributions, no transactions, no fund history.");
  console.log("\nLog in as admin, change the password immediately, then add real members from Admin → Members.");
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
