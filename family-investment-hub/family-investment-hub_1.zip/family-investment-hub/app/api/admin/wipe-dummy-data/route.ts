import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/session";
import { db, withTransaction, run, all } from "@/lib/db";
import { logAudit } from "@/lib/audit";

/**
 * Wipes every member, contribution, transaction, document, notification and
 * audit-log entry, leaving only ADMIN accounts and the current fund
 * settings — the same end state as `npm run db:clean`, but triggered from
 * the running app so it works on a host where you can't run shell commands.
 *
 * Requires typing the exact confirmation phrase, and only an ADMIN can call it.
 */
export async function POST(req: NextRequest) {
  const admin = await requireAdmin();

  const body = await req.json().catch(() => ({}));
  if (body?.confirm !== "WIPE DUMMY DATA") {
    return NextResponse.json(
      { error: 'Type "WIPE DUMMY DATA" exactly to confirm.' },
      { status: 400 }
    );
  }

  const memberUserIds = all<{ user_id: string }>(
    `SELECT user_id FROM members`
  ).map((r) => r.user_id);

  const counts = withTransaction(() => {
    const tableCounts: Record<string, number> = {};
    const countAndDelete = (table: string) => {
      const row = db.prepare(`SELECT COUNT(*) as c FROM ${table}`).get() as any;
      tableCounts[table] = row?.c ?? 0;
      run(`DELETE FROM ${table}`);
    };

    // Children first, respecting foreign keys.
    countAndDelete("transactions");
    countAndDelete("interest_allocations");
    countAndDelete("contribution_evidence");
    countAndDelete("contributions");
    countAndDelete("fund_valuations");
    countAndDelete("fund_transfers");
    countAndDelete("monthly_commitments");
    countAndDelete("documents");
    countAndDelete("notifications");
    countAndDelete("audit_logs");
    countAndDelete("members");

    // Remove the MEMBER-role login accounts that belonged to those members —
    // ADMIN accounts are never touched.
    if (memberUserIds.length) {
      for (const uid of memberUserIds) {
        run(`DELETE FROM users WHERE id = :id AND role = 'MEMBER'`, { id: uid });
      }
    }
    tableCounts["users(members only)"] = memberUserIds.length;

    return tableCounts;
  });

  // audit_logs was just wiped above, so this is the first row in the fresh log.
  logAudit({
    actorId: admin.id,
    action: "DUMMY_DATA_WIPED",
    entityType: "System",
    entityId: "global",
    newValue: counts,
  });

  return NextResponse.json({ ok: true, deleted: counts });
}
