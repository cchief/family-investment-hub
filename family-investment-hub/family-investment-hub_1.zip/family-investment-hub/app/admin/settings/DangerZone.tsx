"use client";
import { useState } from "react";

const PHRASE = "WIPE DUMMY DATA";

export function DangerZone() {
  const [typed, setTyped] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<null | { ok: boolean; message: string }>(null);
  const [open, setOpen] = useState(false);

  async function wipe() {
    setLoading(true);
    setResult(null);
    try {
      const res = await fetch("/api/admin/wipe-dummy-data", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ confirm: typed }),
      });
      const body = await res.json();
      if (!res.ok) {
        setResult({ ok: false, message: body.error || "Could not wipe data." });
      } else {
        const deletedList = Object.entries(body.deleted as Record<string, number>)
          .filter(([, n]) => n > 0)
          .map(([table, n]) => `${table}: ${n}`)
          .join(", ");
        setResult({
          ok: true,
          message: deletedList
            ? `Cleared — ${deletedList}. Only your admin login and fund settings remain.`
            : "Already clean — nothing to remove.",
        });
        setTyped("");
        setOpen(false);
      }
    } catch (e: any) {
      setResult({ ok: false, message: e.message || "Request failed." });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="card p-5 space-y-3 border border-red-200">
      <div>
        <h2 className="font-display text-lg font-semibold text-red-700">Danger Zone</h2>
        <p className="text-ink/50 text-sm mt-1">
          Permanently deletes every member, contribution, transaction, document and notification —
          leaving only admin logins and the fund settings above. This cannot be undone. Use this once,
          before real members start using the app.
        </p>
      </div>

      {!open && (
        <button className="btn bg-red-600 text-white hover:bg-red-700" onClick={() => setOpen(true)}>
          Wipe dummy data…
        </button>
      )}

      {open && (
        <div className="space-y-2 rounded-lg border border-red-200 bg-red-50 p-4">
          <label className="label">
            Type <span className="font-mono font-bold">{PHRASE}</span> to confirm
          </label>
          <input
            className="input"
            value={typed}
            onChange={(e) => setTyped(e.target.value)}
            placeholder={PHRASE}
            autoComplete="off"
          />
          <div className="flex gap-2">
            <button
              className="btn bg-red-600 text-white hover:bg-red-700 disabled:opacity-50"
              disabled={typed !== PHRASE || loading}
              onClick={wipe}
            >
              {loading ? "Wiping…" : "Confirm — wipe everything"}
            </button>
            <button className="btn" onClick={() => { setOpen(false); setTyped(""); }} disabled={loading}>
              Cancel
            </button>
          </div>
        </div>
      )}

      {result && (
        <div className={`text-sm rounded-md p-3 ${result.ok ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"}`}>
          {result.message}
        </div>
      )}
    </div>
  );
}
